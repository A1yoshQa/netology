# Ansible Collection: my_own_namespace.yandex_cloud_elk

The collection create text file with your content.


## Install

Clone this repository yourself.

```
collections:
- name: my_own_namespace.yandex_cloud_elk
```

## Included

Modules:
- my_own_module - create text file with your content 

Roles:
- create-text-file - uses module my_own_module

